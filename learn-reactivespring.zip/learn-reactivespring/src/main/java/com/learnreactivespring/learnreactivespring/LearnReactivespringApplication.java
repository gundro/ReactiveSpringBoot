package com.learnreactivespring.learnreactivespring;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

import com.learnreactivespring.learnreactivespring.controllers.UsersController;
import com.learnreactivespring.learnreactivespring.entity.Users;
import com.learnreactivespring.learnreactivespring.repository.UserRepository;

import jdk.internal.jline.internal.Log;
import reactor.core.publisher.Mono;

@SpringBootApplication
@EnableReactiveMongoRepositories
public class LearnReactivespringApplication {
	private static org.slf4j.Logger log = (org.slf4j.Logger) LoggerFactory.getLogger(LearnReactivespringApplication.class);
	
	@Autowired
	UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(LearnReactivespringApplication.class, args);
	}
	
	
	@Bean
	CommandLineRunner runner() {
		return args -> {

			Mono<Void> sss = userRepository.deleteAll();

			sss.subscribe((e) -> {

			}, Throwable::printStackTrace);

			for (int i = 0; i <= 5; i++) {
				Users user= new Users("Test"+i, "1" + i);
				user.setId(i);

				Mono<Users> data = userRepository.save(user);

				data.subscribe((e) -> {
					log.info(e.toString());
				}, Throwable::printStackTrace);
			}
	};

	}


}
