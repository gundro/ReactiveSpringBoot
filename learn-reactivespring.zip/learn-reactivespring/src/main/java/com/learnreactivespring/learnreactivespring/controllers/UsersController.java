/**
 * 
 */
package com.learnreactivespring.learnreactivespring.controllers;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learnreactivespring.learnreactivespring.entity.Users;
import com.learnreactivespring.learnreactivespring.service.UserService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author ronithrajgund
 *
 */

@RestController
@RequestMapping("/users")
public class UsersController {
	
	private static org.slf4j.Logger log = (org.slf4j.Logger) LoggerFactory.getLogger(UsersController.class);
	

	@Autowired
	UserService service;

	@GetMapping
	public Flux<Users> getAllUser() {
		Flux<Users> allUsers = service.findAll();
		allUsers.subscribe((e) -> {
			log.info(e.toString());
		}, Throwable::printStackTrace);
		return allUsers;
		
	}

	@PostMapping
	public Mono<Users> createUser(@RequestBody Users user) {
		Mono<Users> userObj =  service.save(user);
		userObj.subscribe((e) -> {
			log.info(e.toString());
		}, Throwable::printStackTrace);
		return userObj;
	}

	@GetMapping("/{id}")
	public Mono<ResponseEntity<Users>> getUserById(@PathVariable(value = "id") int userId) {
		Mono<ResponseEntity<Users>> response = service.findById(userId).map(savedTweet -> ResponseEntity.ok(savedTweet))
				.defaultIfEmpty(ResponseEntity.notFound().build());
		response.subscribe((e) -> {
			log.info(e.toString());
		}, Throwable::printStackTrace);
		return response;
	}

	@PutMapping("{id}")
	public Mono<Users> updateById(@PathVariable("id") final String id, @RequestBody final Users user) {
		log.info("::Update the user record::");
		Mono<Users> updatedUser = service.update(id, user);
		updatedUser.subscribe((e) -> {
			log.info(e.toString());
		}, Throwable::printStackTrace);
		return updatedUser;
		
	}

	@DeleteMapping("{id}")
	public Mono<Users> delete(@PathVariable final Integer id) {
		log.info("::Will delete a User::");
		Mono<Users> deletedUser = service.delete(id);
		deletedUser.subscribe((e) -> {
			log.info(e.toString());
		}, Throwable::printStackTrace);
		return deletedUser;
	}

}
