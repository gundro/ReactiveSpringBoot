/**
 * 
 */
package com.learnreactivespring.learnreactivespring.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.learnreactivespring.learnreactivespring.entity.Users;

import reactor.core.publisher.Flux;

/**
 * @author ronithrajgund
 *
 */
public interface UserRepository extends ReactiveMongoRepository<Users, Integer> {
	
	Flux<Users> findByName(String name);

}
