/**
 * 
 */
package com.learnreactivespring.learnreactivespring.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learnreactivespring.learnreactivespring.entity.Users;
import com.learnreactivespring.learnreactivespring.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author ronithrajgund
 *
 */
@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;

	public Mono<Users> update(String id, Users user) {
		return userRepository.save(user);
	}

	public Flux<Users> findAll() {
		return userRepository.findAll();
	}

	public Mono<Users> save(Users user) {
		return userRepository.save(user);
	}

	public Mono<Users> findById(int userId) {
		return userRepository.findById(userId);
	}

	public Mono<Users> delete(Integer id) {
		final Mono<Users> dbUser = findById(id);
		  if (Objects.isNull(dbUser)) {
		   return Mono.empty();
		  }
		  return findById(id).switchIfEmpty(Mono.empty()).filter(Objects::nonNull).flatMap(userToBeDeleted -> userRepository
		    .delete(userToBeDeleted).then(Mono.just(userToBeDeleted)));
		 }

}
